# mlx-delegate — version history

Split out of SKILL.md at v2.7.0 to keep the operational file short.
Nothing here is needed to *use* the skill — it is the record of why the
guidance says what it says.


**v2.7.0 (2026-08-01) — corrections, not additions:**
- Source: a real telescope-simulator session (5 delegations) plus a full day of
  bridge testing. Deliberately kept small — the file was 793 lines and a
  document that flags everything emphasizes nothing.
- **Timing was wrong in four places.** "~5-10s" for 8B is true only of
  one-liners; measured reality is ~2s to load, ~15s for a short function, 88s
  for ~2,600 chars, and 4+ minutes for a full test file. The wrong figure was
  load-bearing for a routing decision ("8B is only 5-10s anyway"). Added the
  rule that follows from it: poll until a terminal marker, never budget a fixed
  number of polls.
- **Removed the Granite 3.3-2B sections** (64 lines) and the model-choice table.
  The weights are no longer installed; the guidance would have routed work to a
  model that isn't there and triggered a silent multi-GB download.
- **Added "say what to do, never what not to do"** as the first prompt-writing
  rule, with evidence from two independent sessions: "structure only, no
  physics values" produced invented tests anyway, and "return only the code, no
  explanation" caused an outright refusal. Positive enumeration fixed both.
- Moved this changelog out of SKILL.md.

**v2.6.0 (2026-07-31) — the self-test had never actually worked:**
- Source: `POWER_AND_MEMORY_2026-07-30.md` in the Cloud2GroundAI repo, written
  alongside the session that found all of this
- **The v2.5.0 self-test failed on every single request from the day it
  shipped**, for two independent reasons, each masking the next. First the
  model prefixes its output with an invisible character — and *which* one
  varies per run (U+200B one-shot, U+200C in resident mode, once a mangled
  U+FFFD) — which landed on `gen.py` line 1 and made python refuse to compile
  the file. With that fixed, Granite's habitual `Citation:` epilogue was still
  being fed to the interpreter as if it were code. Both fixed; the watcher now
  strips the whole Unicode invisible/format class and extracts only the first
  fenced block
- **The documented 10s timeout never killed anything.** `$!` captured the
  subshell's pid rather than python's, so `kill -9` hit the wrong process and
  the interpreter was orphaned to launchd, spinning forever, while the watcher
  reported a clean timeout. Two orphans were found 4.5 days old at ~2 W each
  (~215 Wh). Fixed with `exec` plus a kernel-enforced `ulimit -t` backstop —
  non-terminating generated code is now genuinely safe to smoke-test
- Step 6 gains a discriminator between a **harness** failure and a **code**
  failure, because the previous "a FAILED result means discard or retry"
  advice was, for nine days, instructing agents to throw away correct code
- Trust note corrected: the timeout and CPU cap bound how long generated code
  runs, and nothing else — they are not a sandbox
- **Prompt guidance reversed on evidence:** ask for a fenced ```python block
  rather than "only the code, no explanation." The latter makes Granite refuse
  and emit a conversational preamble instead, which was the source of the
  last intermittent smoke-test failures. Found by adding failure logging
  rather than by another reproduction hunt — the watcher now dumps the raw
  model output (hexdumped first line included) to `mlx.log` whenever a smoke
  test fails, so the next weird case is diagnosable from the log alone

**v2.5.0 (2026-07-21) — optional automatic self-test:**
- Source: real delegation feedback from a different project's session —
  the one delegation that happened that night shipped code with two bugs
  (a hallucinated `csv.reader(comment="#")` stdlib argument, and a
  `peak_scale` applied only to an interpolation delta instead of the whole
  value) that a human caught in review but automation would have caught
  immediately
- New optional `# smoke-test: <expr>` / `# smoke-test: <expr> == <expected>`
  prompt line (see Step 5): the watcher `exec`s the generated Python and
  evaluates the expression, prepending `SELF-TEST: PASSED/FAILED/SKIPPED`
  as the response's first line — bare form catches a crash, `==` form also
  catches a wrong-but-non-crashing value
- Implemented in `watch_mlx_v2.sh` (`run_smoke_test()`), not
  `bridge_delegate` — the latter is deliberately kept portable to the
  Cowork Linux sandbox with no python/jq dependency; the watcher is the
  one place a python3 interpreter for the generated code reliably exists
- Opt-in only (no line, no behavior change) and advisory rather than
  blocking — not every delegatable task reduces to one checkable call, so
  this doesn't gate `bridge_delegate`'s own DONE/TIMEOUT/WAITING protocol
- Step 6 updated to check the `SELF-TEST:` line first, before manual
  smoke-testing

**v2.4.0 (2026-07-19) — orchestrator-level lessons from the same session:**
- Source: `SKILL_LESSONS_2026-07-19.md`, written alongside the v2.3.0 session
  as a separate pass over what the session implied for the skill itself
- Step 1: documented that the MLX watcher LaunchAgent is independent of any
  GUI app or IDE — confirmed live that closing Xcode killed only the
  debug-launched menu-bar app, not the watcher
- Economic-argument section: noted that a session can legitimately delegate
  zero tasks when every task shape hits Step 3's own "keep in cloud" rows —
  that's the routing table working, not a gap to feel bad about
- Step 6: added a determinism check alongside correctness — any generator
  serializing a `dict`/JSON output built from a `set()` (unordered,
  hash-randomized per process) into a file meant to be diffed or
  version-controlled needs a stable declared iteration order, or every
  regeneration produces full-file diff noise that buries real regressions
- New **Autonomous / overnight sessions** section: bypass-permissions mode
  only takes effect from a fresh session start, not mid-session; scoped Bash
  allowlist rules only match one exact invocation string; commit early/often/
  atomically so a forced restart costs nothing; cloud-synced folders (e.g.
  ProtonDrive) can produce spurious sync-conflict duplicate files under rapid
  repeated writes — diff against the real file and gitignore the pattern if
  identical

**v2.3.0 (2026-07-19) — lessons from first real-project test session:**
- Source: Material Optimization project, 4 delegations, 3 correctly not
  shipped (caught at Step 6, not after)
- Fixed `bridge_delegate`'s `cmd_poll`: `TIMEOUT` was firing purely on
  elapsed time, without checking whether `processing.lock` was still
  present. A 10-test generation blew the 120s budget while genuinely still
  running, was reported as `TIMEOUT`, and completed correctly on the very
  next poll. Now: budget exceeded + `processing.lock` still present →
  `WAITING`, not `TIMEOUT`. Applied to all three deployed copies (outer
  `skill/`, bundled Cloud2Ground copy, and the live
  `~/.claude/skills/mlx-delegate/` copy orchestrators actually resolve)
- New **Prompt-writing checklist** section (between Step 3 and Step 4):
  name the exact shape-discriminator instead of describing shapes and
  trusting `isinstance`-style inference; state scaling/units on `_pct`-style
  fields explicitly; answer "what if X is missing" directly; state the
  default for unrecognized/edge-case input explicitly for validation tasks
- New known limitation on Granite 3.3-8B: will sometimes invent plausible
  extra behavior even when the spec's explicit wording already rules it
  out — not the same failure mode as an ambiguous spec, and the checklist
  above won't catch it; only re-reading against the spec's exact sentences
  will

**v2.2.0 (2026-07-19) — confirm-first for long prompts:**
- New Step 4: for prompts near the 100-word local/cloud line (or bundling
  multiple sub-tasks), send a cheap "restate the task and flag ambiguity"
  probe before the real request, using the same `bridge_delegate`
  `send`/`poll` primitives — no protocol or `bridge_delegate` changes needed
- Deliberately not a confidence score — small models self-report as
  confident regardless of accuracy; restating the task gives the
  orchestrator something concrete to judge instead
- Skip this step for short, single-purpose prompts (the common case when
  Step 3's chunking is doing its job) — the extra round-trip only pays for
  itself on prompts long/complex enough that a misfire is expensive

**v2.1.0 (2026-07-18) — MLX-only, no Ollama fallback:**
- Dropped the "backward compatibility with Ollama" path — v2.0 ships MLX-only
- `bridge_delegate`'s `cmd_status()` no longer parses the legacy seq/state/
  last_seen schema; it only understands the current status/last_heartbeat one
- Fixed: `cmd_status()` was misreading the current schema as `DEAD` because it
  only knew the old one — real bug, not a dead watcher
- Fixed: `savings.json`'s `estimated_cost_saved_usd` could render without a
  leading zero (`.013452`), invalid JSON — `bc` output quirk
- Fixed: `C2G_MLX_TEMPERATURE` was shown in `status.json` but never actually
  passed to the model — generation ran at library-default temperature 0.6,
  not the documented 0.2
- Added `topP: 0.9` and `maxTokens: 4096` to generation params per the
  production plan's Phase 1.1 spec (previously unset/unbounded)
- Ported markdown fence-stripping from the retired Ollama watcher — 8B output
  embeds fenced code blocks inside prose, which is a real display difference
  the mechanical delegation contract didn't previously handle
- Default model changed 2B → 8B: the 2B model reliably produced malformed
  code (JS/Python syntax mashups) on trivial prompts regardless of
  temperature; 8B did not

**v2.0.0 (2026-07-18) — MLX-Swift backend:**
- Removed Ollama dependency entirely
- Added savings tracking
- Made heartbeat mandatory
- Updated model naming convention
- Added backend indicator in status
- 8B model now default (quality over speed since async)
- Simplified Step 1 (no pre-v0.4 fallback needed)

**v0.4.0 (2026-07-13) — bridge_delegate helper introduced** (applies to both)

---

